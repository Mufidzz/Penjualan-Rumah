<?php

error_reporting(E_ALL);
date_default_timezone_set('Asia/Jakarta');

$key = "homepedia";
$iss = "http://localhost/";
$aud = "http://localhost/";
$iat = "1356999524";
$nbf = "1357000000";