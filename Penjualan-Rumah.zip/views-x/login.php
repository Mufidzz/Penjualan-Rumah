<html>
<head>
    <link rel="stylesheet" type="text/css" href="/views/css/global.css"/>
    <link rel="stylesheet" type="text/css" href="/views/css/login.css"/>
    <link rel="stylesheet" type="text/css" href="/views/css/m/login.css"/>
    <link rel="stylesheet" type="text/css" href="/views/css/navbar.css"/>
    <link rel="stylesheet" type="text/css" href="/views/css/m/navbar.css"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <div class="header-container">
        <div class="left-side-container">

        </div>
    </div>
    <div class="content-container">
        <label>Sign in</label>
        <form>
            <input type="text" placeholder="username">
            <input type="password" placeholder="password">
            <button>Sign in</button>
        </form>
        <a href="/register">not yet member? register</a>
    </div>
</body>
</html>
